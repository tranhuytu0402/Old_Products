import * as React from 'react';
import classNames from 'classnames/bind';
import styles from './DSPhim.module.scss';

// const cx = classNames.bind(styles);

function DSPhim() {
    return (
        <div>
            <div className="container">
                <h1>DS PHIM</h1>
            </div>
        </div>
    );
}

export default DSPhim;
