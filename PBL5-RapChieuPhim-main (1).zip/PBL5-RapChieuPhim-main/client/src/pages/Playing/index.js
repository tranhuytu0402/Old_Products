function Playing() {
    return <h1>Playing pages</h1>;
}

export default Playing;
