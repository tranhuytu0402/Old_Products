function Evenring() {
    return <h1>Evenring pages</h1>;
}

export default Evenring;
