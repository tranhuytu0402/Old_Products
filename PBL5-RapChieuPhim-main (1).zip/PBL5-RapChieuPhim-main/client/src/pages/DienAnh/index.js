function DienAnh() {
    return <h1>DienAnh pages</h1>;
}

export default DienAnh;
