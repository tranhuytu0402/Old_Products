function LichChieu() {
    return <h2>Lich Chiếu</h2>;
}

export default LichChieu;
