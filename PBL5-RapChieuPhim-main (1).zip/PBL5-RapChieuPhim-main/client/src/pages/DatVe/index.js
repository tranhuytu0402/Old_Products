function DatVe() {
    return <h1>DatVe pages</h1>;
}

export default DatVe;
