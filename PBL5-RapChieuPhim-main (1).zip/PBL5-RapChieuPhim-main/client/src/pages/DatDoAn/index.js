function DatDoAn() {
    return <h1>DatDoAn pages</h1>;
}

export default DatDoAn;
