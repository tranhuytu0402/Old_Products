function Blog() {
    return <h1>Blog pages</h1>;
}

export default Blog;
