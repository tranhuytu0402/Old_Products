function Admin() {
    return <h1>Admin pages</h1>;
}

export default Admin;
