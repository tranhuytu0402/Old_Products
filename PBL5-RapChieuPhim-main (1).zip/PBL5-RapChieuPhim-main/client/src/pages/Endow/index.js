function Endow() {
    return <h1>Endow pages</h1>;
}

export default Endow;
