function Profile() {
    return <h1>Profile pages</h1>;
}

export default Profile;
