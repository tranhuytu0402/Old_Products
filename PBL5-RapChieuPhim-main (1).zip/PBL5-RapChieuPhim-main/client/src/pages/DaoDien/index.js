function DaoDien() {
    return <h1>DaoDien pages</h1>;
}

export default DaoDien;
