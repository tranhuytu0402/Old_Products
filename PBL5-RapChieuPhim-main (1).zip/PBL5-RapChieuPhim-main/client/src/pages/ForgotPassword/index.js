function ForgotPassword() {
    return <h1>ForgotPassword pages</h1>;
}

export default ForgotPassword;
