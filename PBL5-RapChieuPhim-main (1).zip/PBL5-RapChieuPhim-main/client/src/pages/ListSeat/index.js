function ListSeat() {
    return <h1>ListSeat pages</h1>;
}

export default ListSeat;
