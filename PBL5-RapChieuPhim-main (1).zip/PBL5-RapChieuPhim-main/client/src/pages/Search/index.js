function Search() {
    return <h1>Search pages</h1>;
}

export default Search;
