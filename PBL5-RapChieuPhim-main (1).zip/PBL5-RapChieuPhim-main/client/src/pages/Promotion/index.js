function Promotion() {
    return <h1>Promotion pages</h1>;
}

export default Promotion;
