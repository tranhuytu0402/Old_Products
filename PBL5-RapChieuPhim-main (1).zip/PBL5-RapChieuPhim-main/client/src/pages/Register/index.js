function Register() {
    return <h1>Register pages</h1>;
}

export default Register;
