function Cinema() {
    return <h1>Cinema pages</h1>;
}

export default Cinema;
