function MovieBlog() {
    return <h1>MovieBlog pages</h1>;
}

export default MovieBlog;
