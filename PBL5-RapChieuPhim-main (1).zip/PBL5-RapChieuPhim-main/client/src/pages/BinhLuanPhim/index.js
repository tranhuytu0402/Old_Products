function BinhLuanPhim() {
    return <h1>BinhLuanPhim pages</h1>;
}

export default BinhLuanPhim;
