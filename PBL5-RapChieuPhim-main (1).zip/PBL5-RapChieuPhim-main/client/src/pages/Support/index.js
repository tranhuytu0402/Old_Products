function Following() {
    return <h1>Following pages</h1>;
}

export default Following;
