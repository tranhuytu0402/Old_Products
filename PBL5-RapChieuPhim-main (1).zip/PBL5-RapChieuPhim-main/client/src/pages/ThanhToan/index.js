function ThanhToan() {
    return <h1>ThanhToan pages</h1>;
}

export default ThanhToan;
