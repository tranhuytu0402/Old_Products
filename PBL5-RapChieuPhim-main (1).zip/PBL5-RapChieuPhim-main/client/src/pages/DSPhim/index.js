function DSPhim() {
    return <h1>DSPhim pages</h1>;
}

export default DSPhim;
