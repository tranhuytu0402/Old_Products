function DienVien() {
    return <h1>DienVien pages</h1>;
}

export default DienVien;
