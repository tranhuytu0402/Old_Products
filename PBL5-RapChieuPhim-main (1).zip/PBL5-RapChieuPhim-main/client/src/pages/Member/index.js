function Member() {
    return <h1>Thành Viên pages</h1>;
}

export default Member;
