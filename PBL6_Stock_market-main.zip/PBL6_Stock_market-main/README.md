# 1y Target Est: Giá mục tiêu trong vòng 1 năm dự kiến là 198.01.

# 52 Week Range: Phạm vi giá trong vòng 52 tuần gần nhất, từ thấp nhất là 124.17 đến cao nhất là 198.23.

# Ask: Giá mà người bán đang yêu cầu để bán cổ phiếu (trong trường hợp này là '0.00 x 800', nghĩa là không có giá hiện tại và có 800 cổ phiếu có sẵn để bán).

# Avg. Volume: Số lượng cổ phiếu trung bình được giao dịch mỗi ngày, ở đây là 56,874,075 cổ phiếu.

# Beta (5Y Monthly): Hệ số beta, một độ đo cho biết cổ phiếu phản ứng như thế nào so với thị trường, trong 5 tháng gần đây là 1.31.

# Bid: Giá mà người mua đang sẵn lòng trả để mua cổ phiếu (trong trường hợp này là '0.00 x 900', nghĩa là không có giá hiện tại và có 900 cổ phiếu có sẵn để mua).

# Day's Range: Phạm vi giá trong ngày, từ thấp nhất là 190.21 đến cao nhất là 194.40.

# EPS (TTM): Lợi nhuận trên mỗi cổ phiếu trong 12 tháng gần đây, là 6.27.

# Earnings Date: Ngày dự kiến công bố kết quả tài chính (từ ngày 31 tháng 1 đến ngày 5 tháng 2 năm 2024).

# Ex-Dividend Date: Ngày chia cổ tức cuối cùng, là ngày 10 tháng 11 năm 2023.

# Forward Dividend & Yield: Dự kiến cổ tức và tỷ suất cổ tức tiếp theo (ở đây là '0.96 (0.51%)').

# Market Cap: Giá trị vốn hóa thị trường, ở đây là 3.008 tỷ đô la.

# Open: Giá mở cửa trong ngày, ở đây là 190.21.

# PE Ratio (TTM): Tỷ lệ giá so với lợi nhuận trên cổ phiếu trong 12 tháng gần đây, là 30.85.

# Previous Close: Giá đóng cửa trước đó, là 189.43.

# Quote Price: Giá hiện tại của cổ phiếu, là 193.42.

# Volume: Số lượng cổ phiếu đã được giao dịch trong ngày, là 63,350,286 cổ phiếu.
#   P B L 6 _ S t o c k _ m a r k e t  
 #   P B L 6 _ S t o c k _ m a r k e t  
 